import { Component, OnInit } from '@angular/core';
import {NgbTypeahead} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-ccaa',
  templateUrl: './ccaa.component.html',
  styleUrls: ['./ccaa.component.scss']
})
export class CcaaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
